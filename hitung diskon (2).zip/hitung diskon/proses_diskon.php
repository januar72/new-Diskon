<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$nama =$_POST['nama'];
	$harga =$_POST['harga'];
	$jumlah =$_POST['jumlah'];
	$diskon =$_POST['diskon'];

$simpan =mysqli_query($konek, "INSERT INTO `tb_diskon` (`id_diskon`,`nama`,`harga`,`jumlah`,`diskon`) VALUES (null, '$nama','$harga','$jumlah','$diskon')");
header("location:barang.php");
}

 ?>