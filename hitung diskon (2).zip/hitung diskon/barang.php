<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Data Barang</title>

	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<div class="container ml-5 mt-5">
	<form method="post" action="proses_diskon.php">
		<div class="row">
			<div class="col-lg-7">
				<div class="form-group">
					<label>Nama Barang</label>
					<input type="text" name="nama" class="form-control">
				</div>
				<div class="form-group">
					<label>Harga</label>
					<input type="number" name="harga" class="form-control">
				</div>
				<div class="form-group">
					<label>Jumlah</label>
					<input type="number" name="jumlah" class="form-control">
				</div>
				<div class="form-group">
					<label>Pot Diskon (sat|10~%)</label>
					<input type="number" name="diskon" class="form-control">
				</div>
				<div class="box-footer">
					<input type="submit" name="simpan" class="btn btn-primary">
				</div>
			</div>
		</div>
	</form>
</div>
<div class="container mb-5 mt-5">
	<table class="table table-bordered table-striped">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Harga</th>
				<th>Jumlah</th>
				<th>Total</th>
				<th>Pot Diskon</th>
				<th>Total Bayar</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php include 'koneksi.php';
			$no=1;
			$tampil =mysqli_query($konek, "SELECT * FROM tb_diskon");
			while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {
			 	$total =$data['harga'] * $data['jumlah'];
			 	if ($total >= 80000) {
			 		$total_diskon =($total * $data['diskon']) / 100;
			 		$total_bayar =($total - $total_diskon);
			 	}elseif ($total >= 70000) {
			 		$total_diskon =($total * $data['diskon'])/ 100;
			 		$total_bayar =($total - $total_diskon);
			 	}
			  ?>
			 	<tr>
			 		<td><?php echo $no++; ?></td>
			 		<td><?php echo $data['nama']; ?></td>
			 		<td><?php echo $data['harga']; ?></td>
			 		<td><?php echo $data['jumlah']; ?></td>
			 		<td><?php echo @$total; ?></td>
			 		<td><?php echo $data['diskon']; ?> %</td>
			 		<td><?php echo @$total_bayar; ?></td>
			 		<td>
			 			<a href="hapus_barang.php?id=<?php echo $data['id_diskon']; ?>" class="btn btn-danger">hapus</a>
			 		</td>
			 	</tr>
			 <?php } ?>
		</tbody>
	</table>
</div>
</body>
</html>