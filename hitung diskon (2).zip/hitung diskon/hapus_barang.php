<?php 
include 'koneksi.php';

$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_diskon WHERE id_diskon='$id'");
header("location:barang.php");

 ?>