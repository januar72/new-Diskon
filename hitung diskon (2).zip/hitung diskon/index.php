<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Hitung diskon</title>
</head>
<body>
<script type="text/javascript">
	function diskon(harga_awal){
		var diskon;
		diskon = 0.5 * harga_awal;
		harga_diskon =harga_awal - diskon;
		return harga_diskon;
	} 
	var harga =prompt('masukan harga : Rp.');
	document.write("harga setelah diskon 50% menjadi Rp : " + diskon(harga));
</script>
</body>
</html>